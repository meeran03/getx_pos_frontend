import { newRidgeState } from 'react-ridge-state'

// create cart state
export const cartState = newRidgeState([])
